package com.packt.sfjd.ch2;

public interface Car {

	void shape();
	void price();
	void color();
}
