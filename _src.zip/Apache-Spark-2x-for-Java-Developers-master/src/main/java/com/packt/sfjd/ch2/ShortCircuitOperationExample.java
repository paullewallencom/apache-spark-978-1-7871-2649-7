package com.packt.sfjd.ch2;

public class ShortCircuitOperationExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*		
		boolean matched = memberNames.stream()
                .anyMatch((s) -> s.startsWith("A"));

System.out.println(matched);

String firstMatchedName = memberNames.stream()
.filter((s) -> s.startsWith("L"))
.findFirst().get();

System.out.println(firstMatchedName);*/

	}

}
